
package pe.dwca.siaec.model;


public class EquipoModel {

  // Equipo
   private String id_equipo;
   private String id_laboratorio;
   private String id_empleado;
   private String tipoEquipo;
   private String marca;
   private String modelo;
   private String serie;
   private String sisOpe;
   private String hostname;
   private String ip;
   private String fecha_reg;
   private String fecha_baj;
   private String estado;
   private String responsable;
   private String inmovilizado;
   
   // Hardware    
  
   private String teclado;
   private String mouse;
   private String monitor;
   private String resolucion;
   private String pulgadas;
   private String discoDuro;
   private String ram;
   private String tarjGrafica;
   private String tarjRed;
   private String lectora;
   private String puerHmdi;
   private String puerUsb;
   private String puerVGA;
   private String observacion;
   
    public EquipoModel() {
    }

	public String getId_laboratorio() {
		return id_laboratorio;
	}

	public void setId_laboratorio(String id_laboratorio) {
		this.id_laboratorio = id_laboratorio;
	}

	public String getId_empleado() {
		return id_empleado;
	}

	public void setId_empleado(String id_empleado) {
		this.id_empleado = id_empleado;
	}

	public String getTipoEquipo() {
		return tipoEquipo;
	}

	public void setTipoEquipo(String tipoEquipo) {
		this.tipoEquipo = tipoEquipo;
	}

	public String getMarca() {
		return marca;
	}

	public void setMarca(String marca) {
		this.marca = marca;
	}

	public String getModelo() {
		return modelo;
	}

	public void setModelo(String modelo) {
		this.modelo = modelo;
	}

	public String getSerie() {
		return serie;
	}

	public void setSerie(String serie) {
		this.serie = serie;
	}

	public String getSisOpe() {
		return sisOpe;
	}

	public void setSisOpe(String sisOpe) {
		this.sisOpe = sisOpe;
	}

	public String getHostname() {
		return hostname;
	}

	public void setHostname(String hostname) {
		this.hostname = hostname;
	}

	public String getIp() {
		return ip;
	}

	public void setIp(String ip) {
		this.ip = ip;
	}

	public String getFecha_reg() {
		return fecha_reg;
	}

	public void setFecha_reg(String fecha_reg) {
		this.fecha_reg = fecha_reg;
	}

	public String getFecha_baj() {
		return fecha_baj;
	}

	public void setFecha_baj(String fecha_baj) {
		this.fecha_baj = fecha_baj;
	}

	public String getEstado() {
		return estado;
	}

	public void setEstado(String estado) {
		this.estado = estado;
	}

	public String getResponsable() {
		return responsable;
	}

	public void setResponsable(String responsable) {
		this.responsable = responsable;
	}

	public String getInmovilizado() {
		return inmovilizado;
	}

	public void setInmovilizado(String inmovilizado) {
		this.inmovilizado = inmovilizado;
	}

	public String getId_equipo() {
		return id_equipo;
	}

	public void setId_equipo(String id_equipo) {
		this.id_equipo = id_equipo;
	}

	public String getTeclado() {
		return teclado;
	}

	public void setTeclado(String teclado) {
		this.teclado = teclado;
	}

	public String getMouse() {
		return mouse;
	}

	public void setMouse(String mouse) {
		this.mouse = mouse;
	}

	public String getMonitor() {
		return monitor;
	}

	public void setMonitor(String monitor) {
		this.monitor = monitor;
	}

	public String getResolucion() {
		return resolucion;
	}

	public void setResolucion(String resolucion) {
		this.resolucion = resolucion;
	}

	public String getPulgadas() {
		return pulgadas;
	}

	public void setPulgadas(String pulgadas) {
		this.pulgadas = pulgadas;
	}

	public String getDiscoDuro() {
		return discoDuro;
	}

	public void setDiscoDuro(String discoDuro) {
		this.discoDuro = discoDuro;
	}

	public String getRam() {
		return ram;
	}

	public void setRam(String ram) {
		this.ram = ram;
	}

	public String getTarjGrafica() {
		return tarjGrafica;
	}

	public void setTarjGrafica(String tarjGrafica) {
		this.tarjGrafica = tarjGrafica;
	}

	public String getTarjRed() {
		return tarjRed;
	}

	public void setTarjRed(String tarjRed) {
		this.tarjRed = tarjRed;
	}

	public String getLectora() {
		return lectora;
	}

	public void setLectora(String lectora) {
		this.lectora = lectora;
	}

	public String getPuerHmdi() {
		return puerHmdi;
	}

	public void setPuerHmdi(String puerHmdi) {
		this.puerHmdi = puerHmdi;
	}

	public String getPuerUsb() {
		return puerUsb;
	}

	public void setPuerUsb(String puerUsb) {
		this.puerUsb = puerUsb;
	}

	public String getPuerVGA() {
		return puerVGA;
	}

	public void setPuerVGA(String puerVGA) {
		this.puerVGA = puerVGA;
	}

	public String getObservacion() {
		return observacion;
	}

	public void setObservacion(String observacion) {
		this.observacion = observacion;
	}



    
}
