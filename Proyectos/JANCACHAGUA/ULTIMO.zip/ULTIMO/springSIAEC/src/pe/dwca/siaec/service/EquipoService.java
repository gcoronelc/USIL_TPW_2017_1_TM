
package pe.dwca.siaec.service;

import java.util.Map;
import java.util.List;
import org.springframework.stereotype.Service;

@Service
public class EquipoService extends AbstractJdbcSupport{
    
        public List<Map<String, Object>> conEquipo(String criterio) {
        List<Map<String, Object>> lista;
        String sql = "select \n"
                + "c.chr_cuencodigo as NumCuenta,m.chr_cuencodigo as numMovi,\n"
                + "m.dtt_movifecha as fecha,CONCAT(mo.chr_monecodigo,' ',mo.vch_monedescripcion) as moneda , \n"
                + "CONCAT(tm.chr_tipocodigo,' ',tm.vch_tipodescripcion) as tipoMovi,m.dec_moviimporte as importe\n"
                + "from sucursal s  inner join cuenta c \n"
                + "on s.chr_sucucodigo=c.chr_sucucodigo inner join moneda mo \n"
                + "on c.chr_monecodigo=mo.chr_monecodigo inner join movimiento m \n"
                + "on m.chr_cuencodigo=c.chr_cuencodigo inner join tipoMovimiento tm \n"
                + "on tm.chr_tipocodigo=m.chr_tipocodigo \n"
                + "inner join empleado em on m.chr_emplcodigo=em.chr_emplcodigo \n"
                + "where em.chr_emplcodigo   like ? \n";
        criterio = "%" + criterio.trim() + "%";
        lista = jdbcTemplate.queryForList(sql, criterio);
        return lista;
    }
}
