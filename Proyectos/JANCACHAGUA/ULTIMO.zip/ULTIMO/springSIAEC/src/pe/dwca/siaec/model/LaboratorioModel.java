package pe.dwca.siaec.model;

public class LaboratorioModel {

    private String id_laboratorio;
    private String nomLabo;
    private String jefe_labo;
    private String detalle;

    public LaboratorioModel() {
    }

    public String getId_laboratorio() {
        return id_laboratorio;
    }

    public void setId_laboratorio(String id_laboratorio) {
        this.id_laboratorio = id_laboratorio;
    }

    public String getNomLabo() {
        return nomLabo;
    }

    public void setNomLabo(String nomLabo) {
        this.nomLabo = nomLabo;
    }

    public String getJefe_labo() {
        return jefe_labo;
    }

    public void setJefe_labo(String jefe_labo) {
        this.jefe_labo = jefe_labo;
    }

    public String getDetalle() {
        return detalle;
    }

    public void setDetalle(String detalle) {
        this.detalle = detalle;
    }
    
    
}
