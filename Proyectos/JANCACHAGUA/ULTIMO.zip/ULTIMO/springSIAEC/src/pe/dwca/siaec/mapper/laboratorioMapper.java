
package pe.dwca.siaec.mapper;

import java.sql.ResultSet;
import java.sql.SQLException;
import org.springframework.jdbc.core.RowMapper;
import pe.dwca.siaec.model.LaboratorioModel;

public class laboratorioMapper implements RowMapper<LaboratorioModel>{
   
	@Override
    public LaboratorioModel mapRow(ResultSet rs, int i) throws SQLException  {
        LaboratorioModel bean = new LaboratorioModel();
        bean.setId_laboratorio(rs.getString("id_laboratorio"));
        bean.setNomLabo(rs.getString("nomLabo"));
        bean.setJefe_labo(rs.getString("jefe_labo"));
        bean.setDetalle(rs.getString("detalle"));
        return bean;
    }
}
