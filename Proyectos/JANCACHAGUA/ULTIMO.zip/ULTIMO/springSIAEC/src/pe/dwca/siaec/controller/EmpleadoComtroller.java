package pe.dwca.siaec.controller;

import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.SessionAttributes;

import pe.dwca.siaec.model.Empleado;
import pe.dwca.siaec.service.EmpleadoService;
import pe.dwca.siaec.util.SiaecUtil;

@Controller
@SessionAttributes(value = { "empSession", "usuSession", "permisos" })
public class EmpleadoComtroller {
	
    
    @Autowired
    private EmpleadoService empleadoService;
    
    
    
    @RequestMapping(value = "crudEmpleado.htm", method = RequestMethod.GET)
    public String regEmpleadoV1(Model model) {

        String destino = "crudEmpleado";
     //  if (! model.containsAttribute("usuSession")) {
       //    destino = "error/error";
      //}
        return destino;
    }
    
    @RequestMapping(value = "crudEmpleadoConsultar.htm", method = RequestMethod.POST)
    public String crudEmpleadoConsultar(
            @ModelAttribute Empleado bean,
            @RequestParam("btnBuscar") String buscar,
            Model model) {

      String destino;
   //   model.addAttribute("crudLaboratorio", "cssLinkMenuActivo");

     if (buscar.equals("Buscar")) {

       destino = "crudEmpleado";
        List<Empleado> lista = empleadoService.getEmpleados(bean);
        model.addAttribute("lista", lista);

      } else {

    	  Empleado beanEmpleado = new Empleado();
    	  beanEmpleado.setId_empleado(SiaecUtil.CRUD_NUEVO);

        destino = "crudEmpleadoEditar";
        model.addAttribute("accion", SiaecUtil.CRUD_NUEVO);
        model.addAttribute("bean1", beanEmpleado);

      }

      return destino;
    }
    
    @RequestMapping(value = "crudEmpleadoEditar.htm", method = RequestMethod.GET)
    public String crudEmpleadoEditar(
            @RequestParam("id_empleado") String id_empleado,
            Model model) {

      String destino;
      //model.addAttribute("crudClientes", "cssLinkMenuActivo");

      // Proceso
      Empleado beanEmpleado = empleadoService.getEmpleado(id_empleado);

      // Reporte
      destino = "crudEmpleadoEditar";
      model.addAttribute("accion", SiaecUtil.CRUD_EDITAR);
      model.addAttribute("bean1", beanEmpleado);

      return destino;
   }
    
    @RequestMapping(value = "crudEmpleadoEliminar", method = RequestMethod.GET)
    public String crudLaboratorioEliminar(
            @RequestParam("id_empleado") String id_empleado,
            Model model) {

      String destino;
     //model.addAttribute("crudClientes", "cssLinkMenuActivo");

      // Proceso
      Empleado beanEmpleado = empleadoService.getEmpleado(id_empleado);

     // Reporte
      destino = "crudEmpleadoEditar";
     model.addAttribute("accion", SiaecUtil.CRUD_ELIMINAR);
     model.addAttribute("bean1", beanEmpleado);
      model.addAttribute("disabled", "disabled");

      return destino;
   }
    
    @RequestMapping(value = "crudEmpleadoGrabar.htm", method = RequestMethod.POST)
    public String crudLaboratorioGrabar(
            @RequestParam("accion") String accion,
            @ModelAttribute Empleado empleado,
           Model model) {

      String destino;
     // model.addAttribute("crudClientes", "cssLinkMenuActivo");

      // Proceso
     String mensaje = "";
      String error = "";
      try {
        switch (accion) {

         case SiaecUtil.CRUD_NUEVO:
        	 empleadoService.crear1(empleado);
            mensaje = "Empleado creado con c�digo " + empleado.getId_empleado() + ".";
           break;

          case SiaecUtil.CRUD_EDITAR:
        	  empleadoService.update1(empleado);
            mensaje = "Los datos del Empleado se han actualizado correctamente.";
            break;

         case SiaecUtil.CRUD_ELIMINAR:
        	 empleadoService.delete1(empleado.getId_empleado());
            mensaje = "Los datos del Empleado se han eliminado correctamente.";
            break;

       }
      } catch (Exception e) {
        error = e.getMessage();
     }

      // Reporte
      destino = "mensaje";
      model.addAttribute("titulo", accion + " EMPLEADO");
      model.addAttribute("mensaje", mensaje);
      model.addAttribute("error", error);

      return destino;
    }

}
