package pe.dwca.siaec.controller;

import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.SessionAttributes;
import pe.dwca.siaec.service.SiaecService;
import pe.dwca.siaec.model.Combo;
import pe.dwca.siaec.model.EquipoModel;
import pe.dwca.siaec.service.ComboService;
import pe.dwca.siaec.util.SiaecUtil;

@Controller
@SessionAttributes(value = { "empSession", "usuSession", "permisos" })
public class EquipoController {

    @Autowired
    private SiaecService siaecService;

    @Autowired
    private ComboService comboService;

    @RequestMapping(value = "regEquipoV1.htm", method = RequestMethod.GET)
    public String regEquipoV1(Model model) {

        String destino = "regEquipo";
     //  if (! model.containsAttribute("usuSession")) {
       //    destino = "error/error";
      //}
        return destino;
    }

    @RequestMapping(value = "conEquipoV1.htm", method = RequestMethod.GET)
    public String conEquipoV1(Model model) {

        String destino = "conEquipo";
     // if (! model.containsAttribute("usuSession")) {
     //    destino = "error/error";
     //  }
        return destino;
    }

   
}
