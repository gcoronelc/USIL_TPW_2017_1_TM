package pe.dwca.siaec.service;

import java.util.List;
import org.springframework.jdbc.core.BeanPropertyRowMapper;
import org.springframework.stereotype.Service;
import pe.dwca.siaec.model.Empleado;
import pe.dwca.siaec.model.EquipoModel;

@Service
public class SiaecService extends AbstractJdbcSupport {



}
