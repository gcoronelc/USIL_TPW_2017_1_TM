
package pe.dwca.siaec.mapper;

import java.sql.ResultSet;
import java.sql.SQLException;
import org.springframework.jdbc.core.RowMapper;
import pe.dwca.siaec.model.EquipoModel;


public class equipoMapper implements RowMapper<EquipoModel>{
    
    @Override
    public EquipoModel mapRow(ResultSet rs, int i) throws SQLException  {
        EquipoModel bean = new EquipoModel();
        bean.setId_equipo(rs.getString("id_equipo"));
        bean.setId_laboratorio(rs.getString("id_laboratorio"));
        bean.setTipoEquipo(rs.getString("tipoEquipo"));
        bean.setMarca(rs.getString("marca"));
        bean.setModelo(rs.getString("modelo"));
        bean.setSerie(rs.getString("serie"));
        bean.setSisOpe(rs.getString("sisOpe"));
        bean.setHostname(rs.getString("hostname"));
        bean.setIp(rs.getString("ip"));
        bean.setFecha_reg(rs.getString("fecha_reg"));
        bean.setFecha_baj(rs.getString("fecha_baj"));
        bean.setEstado(rs.getString("estado"));
        bean.setResponsable(rs.getString("responsable"));
        bean.setInmovilizado(rs.getString("inmovilizado"));
        return bean;
    }
}
