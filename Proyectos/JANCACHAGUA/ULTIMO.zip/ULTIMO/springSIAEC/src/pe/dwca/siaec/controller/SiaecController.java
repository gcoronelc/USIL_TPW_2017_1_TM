package pe.dwca.siaec.controller;

import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.SessionAttributes;
import org.springframework.web.bind.support.SessionStatus;
import pe.dwca.siaec.model.Empleado;
import pe.dwca.siaec.service.SiaecService;
import pe.dwca.siaec.service.EmpleadoService;

@Controller
@SessionAttributes(value = { "empSession", "usuSession", "permisos" })
public class SiaecController {

    @Autowired
    private SiaecService siaecService;
    
    @Autowired
    private EmpleadoService empleadoService;



    @RequestMapping(value = "/", method = RequestMethod.GET)
    public String home2(SessionStatus sessionStatus) {
        sessionStatus.setComplete();
        return "index";
    }

    @RequestMapping(value = "/index.htm", method = RequestMethod.GET)
    public String home(SessionStatus sessionStatus) {
        sessionStatus.setComplete();
        return "index";
    }

    @RequestMapping(value = "salir.htm", method = RequestMethod.GET)
    public String salir(SessionStatus sessionStatus) {
        sessionStatus.setComplete();
        return "index";
    }

    @RequestMapping(value = "/main.htm", method = RequestMethod.GET)
    public String main() {
        return "main";
    }

    @RequestMapping(value = "empleado.htm", method = RequestMethod.GET)
    public String empleado(Model model) {
        String destino = "empleado";
//        if (!model.containsAttribute("usuario")) {
//            destino = "error/error";
//        }
        return destino;
    }

    @RequestMapping(value = "regDiagnosticoV1.htm", method = RequestMethod.GET)
    public String regDiagnosticoV1(Model model) {

        String destino = "regDiagnostico";
//        if (!model.containsAttribute("usuario")) {
//            destino = "error/error";
//        }
        return destino;
    }
    
//    -----------------------------------------------------------
    	@RequestMapping(value = "/logon.htm", method = RequestMethod.POST)
	public String logon(
		@RequestParam("usuario") String usuario,
		@RequestParam("clave") String clave,
		Model model) {

		String destino;	
		try {
			
			// Proceso
			Empleado bean = empleadoService.validar(usuario, clave);
			if(bean ==  null){
				throw new Exception("Datos incorrectos");
			}
			destino = "main";
			model.addAttribute("empSession", bean);
			model.addAttribute("usuSession", usuario);
			
			// Cargar permisos
			model.addAttribute("permisos", 
					empleadoService.leerPermisos(bean.getId_empleado()));
			
		} catch (Exception e) {

			destino = "index";
			model.addAttribute("error", e.getMessage());
			
		}
		
		return destino;
	}
//    ------------------------------CONSULTAS----------------------------------

    @RequestMapping(value = "conEmpleado.htm", method = RequestMethod.GET)
    public String conEmpleado(Model model) {
        return "conEmpleado";
    }

    @RequestMapping(value = "conEmpleado.htm", method = RequestMethod.POST)
    public String conEmpleado(
            @RequestParam("nombre") String nombre,
            @RequestParam("apellidos") String apellidos,
            Model model) {
        List<Empleado> lista = empleadoService.conEmpleados(nombre, apellidos);
        model.addAttribute("lista", lista);
        model.addAttribute("nombre", nombre);
        model.addAttribute("apellidos", apellidos);

        String destino = "conEmpleado";
//        if (!model.containsAttribute("usuario")) {
//            destino = "error/error";
//        }
        return destino;
    }

}
