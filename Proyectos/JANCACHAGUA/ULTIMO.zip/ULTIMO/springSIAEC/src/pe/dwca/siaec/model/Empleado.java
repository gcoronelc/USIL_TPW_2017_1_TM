package pe.dwca.siaec.model;

import java.io.Serializable;


public class Empleado implements Serializable {

    private static final long serialVersionUID = 6086247716333627610L;
    // Empleado
    private String id_empleado;
    private String nombre;
    private String apellidos;
    private String dni;
    private String cargo;
    private String email;
    private String telefono;  
    private String direccion;
    
    // permisos
    
    private String int_moducodigo;
    private String vch_permestado;
    
    //modelo
    
    private String vch_modunombre;
    private String vch_moduestado;
    
    //Usuario
    
    private String vch_emplusuario;
    private String vch_emplclave;
    private String estado;
    
    
                                 
	public Empleado() {
	}


	public String getId_empleado() {
		return id_empleado;
	}


	public void setId_empleado(String id_empleado) {
		this.id_empleado = id_empleado;
	}


	public String getNombre() {
		return nombre;
	}


	public void setNombre(String nombre) {
		this.nombre = nombre;
	}


	public String getApellidos() {
		return apellidos;
	}


	public void setApellidos(String apellidos) {
		this.apellidos = apellidos;
	}


	public String getDni() {
		return dni;
	}


	public void setDni(String dni) {
		this.dni = dni;
	}


	public String getCargo() {
		return cargo;
	}


	public void setCargo(String cargo) {
		this.cargo = cargo;
	}


	public String getEmail() {
		return email;
	}


	public void setEmail(String email) {
		this.email = email;
	}


	public String getTelefono() {
		return telefono;
	}


	public void setTelefono(String telefono) {
		this.telefono = telefono;
	}


	public String getDireccion() {
		return direccion;
	}


	public void setDireccion(String direccion) {
		this.direccion = direccion;
	}


	public static long getSerialversionuid() {
		return serialVersionUID;
	}


	public String getInt_moducodigo() {
		return int_moducodigo;
	}


	public void setInt_moducodigo(String int_moducodigo) {
		this.int_moducodigo = int_moducodigo;
	}


	public String getVch_permestado() {
		return vch_permestado;
	}


	public void setVch_permestado(String vch_permestado) {
		this.vch_permestado = vch_permestado;
	}


	public String getVch_modunombre() {
		return vch_modunombre;
	}


	public void setVch_modunombre(String vch_modunombre) {
		this.vch_modunombre = vch_modunombre;
	}


	public String getVch_moduestado() {
		return vch_moduestado;
	}


	public void setVch_moduestado(String vch_moduestado) {
		this.vch_moduestado = vch_moduestado;
	}


	public String getVch_emplusuario() {
		return vch_emplusuario;
	}


	public void setVch_emplusuario(String vch_emplusuario) {
		this.vch_emplusuario = vch_emplusuario;
	}


	public String getVch_emplclave() {
		return vch_emplclave;
	}


	public void setVch_emplclave(String vch_emplclave) {
		this.vch_emplclave = vch_emplclave;
	}


	public String getEstado() {
		return estado;
	}


	public void setEstado(String estado) {
		this.estado = estado;
	}
    
	
    

}
