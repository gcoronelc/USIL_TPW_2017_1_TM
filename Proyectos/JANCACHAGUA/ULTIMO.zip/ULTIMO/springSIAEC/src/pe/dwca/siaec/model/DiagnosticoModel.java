package pe.dwca.siaec.model;

public class DiagnosticoModel {

	private String id_equipo;
	private String id_laboratorio;
	private String id_empleado;
	private String descripProble;
	private String sugerencia;
	private String activiRealizada;
	private String fecha;
	private String hora;
	
	
	public DiagnosticoModel() {
		super();
	}


	public String getId_equipo() {
		return id_equipo;
	}


	public void setId_equipo(String id_equipo) {
		this.id_equipo = id_equipo;
	}


	public String getId_laboratorio() {
		return id_laboratorio;
	}


	public void setId_laboratorio(String id_laboratorio) {
		this.id_laboratorio = id_laboratorio;
	}


	public String getId_empleado() {
		return id_empleado;
	}


	public void setId_empleado(String id_empleado) {
		this.id_empleado = id_empleado;
	}


	public String getDescripProble() {
		return descripProble;
	}


	public void setDescripProble(String descripProble) {
		this.descripProble = descripProble;
	}


	public String getSugerencia() {
		return sugerencia;
	}


	public void setSugerencia(String sugerencia) {
		this.sugerencia = sugerencia;
	}


	public String getActiviRealizada() {
		return activiRealizada;
	}


	public void setActiviRealizada(String activiRealizada) {
		this.activiRealizada = activiRealizada;
	}


	public String getFecha() {
		return fecha;
	}


	public void setFecha(String fecha) {
		this.fecha = fecha;
	}


	public String getHora() {
		return hora;
	}


	public void setHora(String hora) {
		this.hora = hora;
	}
	
	
	
	
}
