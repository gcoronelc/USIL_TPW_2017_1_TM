package pe.dwca.siaec.mapper;

import java.sql.ResultSet;
import java.sql.SQLException;
import org.springframework.jdbc.core.RowMapper;
import pe.dwca.siaec.model.Empleado;

public class empleadoMapper  implements RowMapper<Empleado>{

	@Override
    public Empleado mapRow(ResultSet rs, int i) throws SQLException  {
		Empleado bean1 = new Empleado();
        bean1.setId_empleado(rs.getString("id_empleado"));
        bean1.setNombre(rs.getString("nombre"));
        bean1.setApellidos(rs.getString("apellidos"));
        bean1.setDni(rs.getString("dni"));
        bean1.setCargo(rs.getString("cargo"));
        bean1.setEmail(rs.getString("email"));
        bean1.setTelefono(rs.getString("telefono"));
        bean1.setDireccion(rs.getString("direccion"));
        return bean1;
    }
}
