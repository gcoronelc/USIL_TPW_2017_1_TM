package pe.dwca.siaec.controller;

import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.SessionAttributes;
import pe.dwca.siaec.model.Combo;
import pe.dwca.siaec.model.EquipoModel;
import pe.dwca.siaec.service.ComboService;
import pe.dwca.siaec.service.LaboratirioService;
import pe.dwca.siaec.util.SiaecUtil;
import pe.dwca.siaec.model.LaboratorioModel;

@Controller
@SessionAttributes(value = { "empSession", "usuSession", "permisos" })
public class LaboratorioController {



    @Autowired
    private ComboService comboService;
    
    @Autowired
    private LaboratirioService laboratirioService;
	
	@RequestMapping(value = "crudLaboratorio.htm", method = RequestMethod.GET)
    public String regEquipoV1(Model model) {

        String destino = "crudLaboratorio";
     //  if (! model.containsAttribute("usuSession")) {
       //    destino = "error/error";
      //}
        return destino;
    }
	
	 //    --------------------------LABORATORIO----------------------------------
    @RequestMapping(value = "conLaboratorioV2.htm", method = RequestMethod.GET)
    public String conLaboratorioV2(Model model) {

        // Proceso Caso 1
        List<Combo> laboratorios = comboService.getLaboratorios();

        // Reporte
        model.addAttribute("laboratorios", laboratorios);

        String destino = "conLaboratorio";
    //   if (! model.containsAttribute("usuSession")) {
    //        destino = "error/error";
    //   }
        return destino;
    }

    @RequestMapping(value = "conLaboratorioV2.htm", method = RequestMethod.POST)
    public String conLaboratorioV3(
            @RequestParam("laboratorio") String laboratorio,
            Model model) {
    	
        String destino = "conLaboratorio";
//        

//        if ( model.containsAttribute("usuarioSession") ) {
        // Proceso
        List<EquipoModel> lista = laboratirioService.getEquipoLaboratorios(laboratorio);
        List<Combo> laboratorios = comboService.getLaboratorios();
        
        SiaecUtil.selectComboOption(laboratorios, laboratorio);

        // Reporte
        model.addAttribute("laboratorios", laboratorios);
        model.addAttribute("lista", lista);

      //  if (! model.containsAttribute("usuSession")) {
      //      destino = "error/error";
      // }
        return destino;
    }
    
    //----------------------------------------CRUD--------------------------------------


  @RequestMapping(value = "crudLabotarioConsultar.htm", method = RequestMethod.POST)
  public String crudClientesConsultar(
          @ModelAttribute LaboratorioModel bean,
          @RequestParam("btnBuscar") String buscar,
          Model model) {

    String destino;
 //   model.addAttribute("crudLaboratorio", "cssLinkMenuActivo");

   if (buscar.equals("Buscar")) {

     destino = "crudLaboratorio";
      List<LaboratorioModel> lista = laboratirioService.getLaboratorios(bean);
      model.addAttribute("lista", lista);

    } else {

    	LaboratorioModel beanLaboratorio = new LaboratorioModel();
    	beanLaboratorio.setId_laboratorio(SiaecUtil.CRUD_NUEVO);

      destino = "crudLaboratorioEditar";
      model.addAttribute("accion", SiaecUtil.CRUD_NUEVO);
      model.addAttribute("bean", beanLaboratorio);

    }

    return destino;
  }

  @RequestMapping(value = "crudLaboratorioEditar.htm", method = RequestMethod.GET)
  public String crudLaboratorioEditar(
          @RequestParam("id_laboratorio") String id_laboratorio,
          Model model) {

    String destino;
    //model.addAttribute("crudClientes", "cssLinkMenuActivo");

    // Proceso
  LaboratorioModel beanLaboratorio = laboratirioService.getLaboratorio(id_laboratorio);

    // Reporte
    destino = "crudLaboratorioEditar";
    model.addAttribute("accion", SiaecUtil.CRUD_EDITAR);
    model.addAttribute("bean", beanLaboratorio);

    return destino;
 }

 @RequestMapping(value = "crudLaboratorioEliminar", method = RequestMethod.GET)
  public String crudLaboratorioEliminar(
          @RequestParam("id_laboratorio") String id_laboratorio,
          Model model) {

    String destino;
   //model.addAttribute("crudClientes", "cssLinkMenuActivo");

    // Proceso
    LaboratorioModel beanLaboratorio = laboratirioService.getLaboratorio(id_laboratorio);

   // Reporte
    destino = "crudLaboratorioEditar";
   model.addAttribute("accion", SiaecUtil.CRUD_ELIMINAR);
   model.addAttribute("bean", beanLaboratorio);
    model.addAttribute("disabled", "disabled");

    return destino;
 }

 @RequestMapping(value = "crudLaboratorioGrabar.htm", method = RequestMethod.POST)
  public String crudLaboratorioGrabar(
          @RequestParam("accion") String accion,
          @ModelAttribute LaboratorioModel laboratorio,
         Model model) {

    String destino;
   // model.addAttribute("crudClientes", "cssLinkMenuActivo");

    // Proceso
   String mensaje = "";
    String error = "";
    try {
      switch (accion) {

       case SiaecUtil.CRUD_NUEVO:
         laboratirioService.crear(laboratorio);
          mensaje = "Cliente creado con c�digo " + laboratorio.getId_laboratorio() + ".";
         break;

        case SiaecUtil.CRUD_EDITAR:
         laboratirioService.update(laboratorio);
          mensaje = "Los datos del cliente se han actualizado correctamente.";
          break;

       case SiaecUtil.CRUD_ELIMINAR:
          laboratirioService.delete(laboratorio.getId_laboratorio());
          mensaje = "Los datos del cliente se han eliminado correctamente.";
          break;

     }
    } catch (Exception e) {
      error = e.getMessage();
   }

    // Reporte
    destino = "mensaje";
    model.addAttribute("titulo", accion + " CLIENTE");
    model.addAttribute("mensaje", mensaje);
    model.addAttribute("error", error);

    return destino;
  }

}




