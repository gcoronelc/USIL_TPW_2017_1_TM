package pe.dwca.siaec.service;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.dao.EmptyResultDataAccessException;
import org.springframework.jdbc.core.BeanPropertyRowMapper;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;


import pe.dwca.siaec.mapper.empleadoMapper;
import pe.dwca.siaec.model.Empleado;

@Service
public class EmpleadoService extends AbstractJdbcSupport {

	private final String SQL_SELECT = "select "
            + "id_empleado    id_empleado, "
            + "nombre         nombre, "
            + "apellidos      apellidos, "
            + "dni            dni, "
            + "cargo          cargo, "
            + "email          email, "
            + "telefono       telefono, "
            + "direccion      direccion "
            + "from empleado ";

		 private final String SQL_INSERT = "insert into "
		         + "empleado (id_empleado, nombre, apellidos, dni,"
		         + "cargo, email, telefono, direccion ) "
		         + "values(?,?,?,?,?,?,?,?)";
		 
		 private final String SQL_UPDATE = "update empleado set "
		         + "nombre= ?, " 
		         + "apellidos = ?, "
		         + "dni = ?, " 
		         + "cargo = ?, "
		         + "email = ?, " 
		         + "telefono = ?, "
		         + "direccion = ? "
		         + "where id_empleado = ? ";
		 
		 private final String SQL_DELETE = "delete from empleado "
		         + "where id_empleado = ? ";

		 
		 
    public Empleado validar(String usuario, String clave) {
        Empleado bean = null;
        try {
        	String sql = SQL_SELECT 
					+ "where id_empleado = ( "
                    + "select id_empleado from Usuario  "
                    + "where vch_emplusuario = ?  "
                	+ "and vch_emplclave = SHA(?) "
                	 + "and estado = 1)";
            bean = jdbcTemplate.queryForObject(sql, 
					new BeanPropertyRowMapper<Empleado>(Empleado.class), 
					usuario, clave);

        } catch (EmptyResultDataAccessException e) {
        }
        return bean;
    }

    public Map<String, String> leerPermisos(String codEmp) {

        Map<String, String> permisos = new HashMap<>();

        // Recupero la lista
        String sql = "select int_moducodigo cod, vch_permestado estado "
                + "from permiso where id_empleado = ?";
        List<Map<String, Object>> lista = jdbcTemplate.queryForList(sql, codEmp);

        // Pasar la lista a un Map
        for (Map<String, Object> map : lista) {
            permisos.put(
                    "op" + map.get("cod").toString(),
                    map.get("estado").toString());
        }

        return permisos;
    }
    
    public List<Empleado> conEmpleados(String nombre, String apellidos) {
        List<Empleado> lista;
        String sql = SQL_SELECT 
                + "where nombre like concat('%',?,'%')  "
                + "and apellidos like concat('%',?,'%') ";
        lista = jdbcTemplate.query(sql, new BeanPropertyRowMapper(Empleado.class), nombre, apellidos);
        return lista;
    }
    
    //---------------------------------CRUD--------------------------------
    
    public Empleado getEmpleado(String id_empleado){
    	Empleado bean = null;
   	    String sql = SQL_SELECT
   	            + "where id_empleado = ? ";
   	    try {
   	      bean = jdbcTemplate.queryForObject(sql, new empleadoMapper(), id_empleado);
   	    } catch (EmptyResultDataAccessException e) {
   	    }
   	    return bean;
   	  }
    
    public List<Empleado> getEmpleados(Empleado bean){
    	   List<Empleado> lista;
    	   String sql = SQL_SELECT
    	           + "where id_empleado like concat('%',?,'%') "
    	           + "and apellidos like concat('%',?,'%') ";
    	   lista = jdbcTemplate.query(sql, new empleadoMapper(), 
    	           bean.getId_empleado(), bean.getApellidos());
    	   return lista;
    	 }
    
    
    @Transactional(propagation = Propagation.REQUIRED,
            rollbackFor = Exception.class)
    public void crear1(Empleado empleado) {
      
      // Leer el contador
      String sql = "select int_contitem cont, int_contlongitud size "
              + "from contador "
              + "where vch_conttabla = 'Empleado' "
              + "for update";
      Map<String,Object> rec = jdbcTemplate.queryForMap(sql);
      int cont = Integer.parseInt(rec.get("cont").toString());
      int size = Integer.parseInt(rec.get("size").toString());
      

      // Para producci�n se debe borrar
      
      try {
        Thread.currentThread().sleep(5000);
      } catch (Exception e) {
      }
      
      // Generar Codigo
      cont++;
      String codigo = String.format("%" + size + "s", cont).replace(' ', '0' );
      
      // Actualizar el contador
      sql = "update contador set int_contitem = ? "
              + "where vch_conttabla = 'Empleado'";
      jdbcTemplate.update(sql, cont);
      
      // Insertar cliente
      jdbcTemplate.update(SQL_INSERT, codigo, empleado.getNombre(), empleado.getApellidos(), empleado.getDni(), 
    		  empleado.getCargo(), empleado.getEmail(), empleado.getTelefono(), empleado.getDireccion());
      
      empleado.setId_empleado(codigo);
      
    }
    
    //ACTUALIZAR
    
    @Transactional(propagation = Propagation.REQUIRED,
            rollbackFor = Exception.class)
    public void update1(Empleado empleado) {
      
      int filas = jdbcTemplate.update(SQL_UPDATE, empleado.getNombre(),empleado.getApellidos(), 
    		  empleado.getDni(),empleado.getCargo(), 
    		  empleado.getEmail(),empleado.getTelefono(),
    		  empleado.getDireccion(),empleado.getId_empleado());
      
      if( filas != 1){
        throw new RuntimeException("Error en el proceso.");
      }
      
    }
    
    //DELETE
    
     @Transactional(propagation = Propagation.REQUIRED,
          rollbackFor = Exception.class)
    public void delete1(String codigo) {
      
      int filas = jdbcTemplate.update(SQL_DELETE, codigo);
      
      if( filas == 0){
        throw new RuntimeException("El Laboratorio no existe.");
      }
      
    }

}
