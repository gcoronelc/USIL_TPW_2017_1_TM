package pe.dwca.siaec.service;

import java.util.List;
import java.util.Map;
import org.springframework.dao.EmptyResultDataAccessException;
import org.springframework.jdbc.core.BeanPropertyRowMapper;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;
import pe.dwca.siaec.model.LaboratorioModel;
import pe.dwca.siaec.model.EquipoModel;
import pe.dwca.siaec.mapper.laboratorioMapper;

@Service
public class LaboratirioService extends AbstractJdbcSupport{
	
 private final String SQL_SELECT = "select "
		+"id_laboratorio id_laboratorio , "
		+"nomLabo nomLabo, "
		+"jefe_labo jefe_labo, "
		+"detalle  detalle "
		+"from laboratorio ";

 private final String SQL_INSERT = "insert into "
         + "laboratorio (id_laboratorio, nomLabo,"
         + "jefe_labo, detalle ) "
         + "values(?,?,?,?)";
 
 private final String SQL_UPDATE = "update laboratorio set "
         + "nomLabo = ?, " 
         + "jefe_labo = ?, "
         + "detalle = ? "
         + "where id_laboratorio = ? ";
 
 private final String SQL_DELETE = "delete from laboratorio "
         + "where id_laboratorio = ? ";

// /**
//  * Consultar clientes.
//  *
//  * @param criterio Puede ser paterno, materno o nombre
//  * @return Lista de laboratorio usando Map
//  */
 
 public List<Map<String, Object>> conLaboratorio1(String criterio) {
   List<Map<String, Object>> lista;
   String sql = SQL_SELECT
           + "where id_laboratorio   like ? \n"
           + "or    nomLabo   like ? ";
   criterio = "%" + criterio.trim() + "%";
   lista =  jdbcTemplate.queryForList(sql, criterio, criterio);
   return lista;
 }
// 
// /**
//  * Consultar cl�ientes.
//  *
//  * @param criterio Puede ser paterno, materno o nombre
//  * @return Lista de laboratorio usando Bean
//  */
 
 public List<LaboratorioModel> conLaboratorio2(String criterio) {
   List<LaboratorioModel> lista = null;
  String sql = SQL_SELECT
		  + "where id_laboratorio   like ? \n"
          + "or    nomLabo   like ? ";
   criterio = "%" + criterio.trim() + "%";
   lista = jdbcTemplate.query(sql, 
          new BeanPropertyRowMapper(LaboratorioModel.class), 
           criterio, criterio);
   return lista;
 }
 
// 
// /**
//  * Consultar laboratorio
 //    para que cada vez selecciones del combo el area se ejecuta sus equipos del area seleccionado
//  */
 
 public List<EquipoModel> getEquipoLaboratorios(String sucursal) {
     List<EquipoModel> lista = null;
     String sql = "select \n"
             + "id_equipo       id_equipo,\n"
             + "id_laboratorio  id_laboratorio, \n"
             + "id_empleado     id_empleado,\n"
             + "tipoEquipo      tipoEquipo, \n"
             + "marca           marca, \n"
             + "modelo          modelo, \n"
             + "serie           serie, \n"
             + "sisOpe          sisOpe, \n"
             + "hostname        hostname, \n"
             + "ip              ip, \n"
             + "fecha_reg       fecha_reg, \n"
             + "fecha_baj       fecha_baj, \n"
             + "estado          estado, \n"
             + "responsable     responsable, \n"
             + "inmovilizado    inmovilizado \n"
             + "from equipo \n"
             + "where id_laboratorio in "
             + "( select id_laboratorio from laboratorio where id_laboratorio=? ) ";
     lista = jdbcTemplate.query(sql,new BeanPropertyRowMapper(EquipoModel.class), sucursal);
     return lista;
 }
 
 //-------------------------------CRUD---------------------------------------
 
 public LaboratorioModel getLaboratorio(String id_laboratorio){
	 LaboratorioModel bean = null;
	    String sql = SQL_SELECT
	            + "where id_laboratorio = ? ";
	    try {
	      bean = jdbcTemplate.queryForObject(sql, new laboratorioMapper(), id_laboratorio);
	    } catch (EmptyResultDataAccessException e) {
	    }
	    return bean;
	  }

 public List<LaboratorioModel> getLaboratorios( LaboratorioModel bean ){
   List<LaboratorioModel> lista;
   String sql = SQL_SELECT
           + "where id_laboratorio like concat('%',?,'%') "
           + "and nomLabo like concat('%',?,'%') ";
   lista = jdbcTemplate.query(sql, new laboratorioMapper(), 
           bean.getId_laboratorio(), bean.getNomLabo());
   return lista;
 }

 
 
 @Transactional(propagation = Propagation.REQUIRED,
         rollbackFor = Exception.class)
 public void crear(LaboratorioModel laboratorio) {
   
   // Leer el contador
   String sql = "select int_contitem cont, int_contlongitud size "
           + "from contador "
           + "where vch_conttabla = 'laboratorio' "
           + "for update";
   Map<String,Object> rec = jdbcTemplate.queryForMap(sql);
   int cont = Integer.parseInt(rec.get("cont").toString());
   int size = Integer.parseInt(rec.get("size").toString());
   

   // Para producci�n se debe borrar
   
   try {
     Thread.currentThread().sleep(5000);
   } catch (Exception e) {
   }
   
   // Generar Codigo
   cont++;
   String codigo = String.format("%" + size + "s", cont).replace(' ', '0' );
   
   // Actualizar el contador
   sql = "update contador set int_contitem = ? "
           + "where vch_conttabla = 'Laboratorio'";
   jdbcTemplate.update(sql, cont);
   
   // Insertar cliente
   jdbcTemplate.update(SQL_INSERT, codigo, laboratorio.getNomLabo(), 
		   laboratorio.getJefe_labo(),laboratorio.getDetalle());
   
   laboratorio.setId_laboratorio(codigo);
   
 }
 
 //ACTUALIZAR
 
 @Transactional(propagation = Propagation.REQUIRED,
         rollbackFor = Exception.class)
 public void update(LaboratorioModel laboratorio) {
   
   int filas = jdbcTemplate.update(SQL_UPDATE, laboratorio.getNomLabo(), 
  laboratorio.getJefe_labo(),laboratorio.getDetalle(),laboratorio.getId_laboratorio());
   
   if( filas != 1){
     throw new RuntimeException("Error en el proceso.");
   }
   
 }
 
 //DELETE
 
  @Transactional(propagation = Propagation.REQUIRED,
       rollbackFor = Exception.class)
 public void delete(String codigo) {
   
   int filas = jdbcTemplate.update(SQL_DELETE, codigo);
   
   if( filas == 0){
     throw new RuntimeException("El Laboratorio no existe.");
   }
   
 }

}
