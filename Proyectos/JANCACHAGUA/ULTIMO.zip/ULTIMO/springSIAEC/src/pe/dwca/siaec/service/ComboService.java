package pe.dwca.siaec.service;

import java.util.List;
import org.springframework.jdbc.core.BeanPropertyRowMapper;
import org.springframework.stereotype.Service;
import pe.dwca.siaec.model.Combo;

@Service
public class ComboService extends AbstractJdbcSupport {
    
      public List<Combo> getLaboratorios(){
    String sql = "select id_laboratorio codigo, nomLabo nombre from laboratorio";
    List<Combo> lista = jdbcTemplate.query(sql, new BeanPropertyRowMapper(Combo.class));
    return lista;
 
  } 
}
