package pe.dwca.siaec.prueba;



public class SiaecPrueba {

    public static void main(String[] args) {

//    // Datos
//    Empleado model = new Empleado(1,);
//    
//    // Proceso
//       ComboService serviceCombo =new ComboService();
//    model = service.Procesos(model);
//
//    // Reporte
       
//    System.out.println("Horas x Día: " + model.getHorasDia());
       
    }
}
