package pe.dwca.siaec.util;

import java.util.List;
import pe.dwca.siaec.model.Combo;

public final class SiaecUtil {

    private SiaecUtil() {
    }

    public static void selectComboOption(List<Combo> lista, String codigo) {
        for (Combo combo : lista) {
            if (combo.getCodigo().equals(codigo)) {
                combo.setSelected("selected");
            }
        }
    }
    
    // CONSTANTES DEL CRUD
    
    public static final String CRUD_NUEVO = "NUEVO";
    public static final String CRUD_EDITAR = "EDITAR";
    public static final String CRUD_ELIMINAR = "ELIMINAR";
}
