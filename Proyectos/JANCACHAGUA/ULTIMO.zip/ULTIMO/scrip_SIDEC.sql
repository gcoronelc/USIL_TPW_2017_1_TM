drop database if exists bdsiaec;
create database bdsiaec;
use bdsiaec;

 
create table laboratorio(
id_laboratorio CHAR(4) NOT NULL,
nomLabo        varchar(50) ,
jefe_labo      varchar(50),
detalle        varchar(100),
CONSTRAINT PK_laboratorio PRIMARY KEY (id_laboratorio)
);

create table empleado(
id_empleado  CHAR(4) NOT NULL,
nombre       varchar(50) ,
apellidos    varchar(50) ,
dni          char(8),
cargo        varchar(50),
email        varchar(50),
telefono     varchar(50), 
direccion    varchar(50),
CONSTRAINT PK_Empleado PRIMARY KEY (id_empleado)
);  


CREATE TABLE Modulo
(
	int_moducodigo       INTEGER NOT NULL,
	vch_modunombre       VARCHAR(50) NULL,
	vch_moduestado       VARCHAR(15) NOT NULL 
						 DEFAULT 'ACTIVO' 
		                 CHECK ( vch_moduestado IN ('ACTIVO', 'ANULADO', 'CANCELADO') ),
	CONSTRAINT PK_Modulo PRIMARY KEY (int_moducodigo)
) ; 

CREATE TABLE Usuario
(
	id_empleado          CHAR(4) NOT NULL,
	vch_emplusuario      VARCHAR(20) NOT NULL,
	vch_emplclave        VARCHAR(50) NOT NULL,
	estado               NUMERIC(2,0) NOT NULL COMMENT 'Estado del usuario: 1 - Activo 0 - Inactivo',
	CONSTRAINT CHK_USUARIO_ESTADO CHECK ( estado IN (1, 0) ),
	CONSTRAINT PK_Usuario PRIMARY KEY (id_empleado),
	CONSTRAINT U_Usuario_vch_emplusuario UNIQUE (vch_emplusuario),
	FOREIGN KEY FK_Usuario_Empleado (id_empleado) REFERENCES empleado (id_empleado)
);


CREATE TABLE Permiso
(
	id_empleado          CHAR(4) NOT NULL,
	int_moducodigo       INTEGER NOT NULL,
	vch_permestado       VARCHAR(15) NOT NULL 
	                     DEFAULT 'ACTIVO' 
						 CHECK ( vch_permestado IN ('ACTIVO', 'ANULADO', 'CANCELADO') ),
	CONSTRAINT PK_Permiso PRIMARY KEY (id_empleado,int_moducodigo),
	FOREIGN KEY FK_Permiso_Modulo (int_moducodigo) REFERENCES Modulo (int_moducodigo),
	FOREIGN KEY FK_Permiso_Usuario (id_empleado) REFERENCES Usuario (id_empleado)
) ;




create table equipo(
id_equipo        CHAR(4) NOT NULL,
id_laboratorio   CHAR(4) NOT NULL,
id_empleado      CHAR(4) NOT NULL,
tipoEquipo       varchar(50) not null,
marca            varchar(50),
modelo           varchar(50),
serie            varchar(50),
sisOpe           varchar(50),
hostname         varchar(50),
ip               varchar(50),
fecha_reg        date ,
fecha_baj        date ,
estado           varchar(50),
responsable      varchar(50),
inmovilizado     varchar(50)not null,
CONSTRAINT PK_Equipo PRIMARY KEY (id_equipo),
constraint fk_laboEqui foreign key(id_laboratorio) references laboratorio(id_laboratorio),
constraint fk_EmpleEqui foreign key(id_empleado) references usuario(id_empleado)
);


create table hardware(
id_equipo     CHAR(4) not null,
teclado       varchar(50),
mouse         varchar(50),
monitor       varchar(50) ,
resolucion    varchar(50) ,
pulgadas      varchar(50),
discoDuro     varchar(50) ,
ram           varchar(50),
tarjGrafica   varchar(50) ,
tarjRed       varchar(50) ,
lectora       varchar(50),
puerHmdi      varchar(50) ,
puerUsb       varchar(50) ,
puerVGA       varchar(50) ,
observacion   varchar(150),
constraint fk_EquiHard foreign key(id_equipo) references equipo(id_equipo)
);



create table diagnostico(
id_equipo       CHAR(4) NOT NULL,
id_laboratorio  CHAR(4) NOT NULL,
id_empleado     CHAR(4) NOT NULL,
descripProble   varchar(150) ,
sugerencia      varchar(150) ,
activiRealizada varchar(150) ,
fecha           date ,
hora            time  default null,
constraint fk_diagEqui foreign key(id_equipo) references equipo(id_equipo),
constraint fk_diagLabo foreign key(id_laboratorio) references laboratorio(id_laboratorio),
constraint fk_diagEmple foreign key(id_empleado) references usuario(id_empleado)
);

CREATE TABLE Contador (
	vch_conttabla        VARCHAR(30) NOT NULL,
	int_contitem         INTEGER NOT NULL,
	int_contlongitud     INTEGER NOT NULL,
	CONSTRAINT PK_Contador 
		PRIMARY KEY (vch_conttabla)
);

insert into Contador Values( 'equipos', 25, 2 );
insert into Contador Values( 'laboratorio', 5, 3 );
insert into Contador Values( 'Empleado', 5, 4 );
insert into Contador Values( 'diagnostico', 25, 6 );

insert into laboratorio values('0001','RRHH','Lic. Peres','conforme');
insert into laboratorio values('0002','Administracion','Adm. Ernesto','conforme');
insert into laboratorio values('0003','logistica','Ing Hernesto','conforme');
insert into laboratorio values('0004','prosupuesto','Ing Chiroque','conforme');
insert into laboratorio values('0005','caja','Cont. Olivos','conforme');

insert into empleado values('0001','darwin wendy','Crispin armas','45624009','Tco. Informatico','darwin@gmail.com','956934359','calle c');
insert into empleado values('0002','emerson','huaman Linares','44005629','Ing. Sistemas','emerson@gmail.com','954934359','calle c');
insert into empleado values('0003','Maria','Martinez Cardenas','40456209','Secretaria Ejecutivo','maria@gmail.com','956934359','calle c');
insert into empleado values('0004','juaquin','Alamo Salvador','24009456','Tco. Contador','juaquin@gmail.com','954359359','calle c');
insert into empleado values('0005','carlos','Ramirez Yuto','24564009','Lic. Administracion','carlos@gmail.com','954359359','calle c');


INSERT INTO Modulo VALUES( 1, 'Procesos', 'ACTIVO');
INSERT INTO Modulo VALUES( 2, 'Tablas', 'ACTIVO');
INSERT INTO Modulo VALUES( 3, 'Consultas', 'ACTIVO');
INSERT INTO Modulo VALUES( 4, 'Reportes', 'ACTIVO');
INSERT INTO Modulo VALUES( 5, 'Util', 'ACTIVO');
INSERT INTO Modulo VALUES( 6, 'Seguridad', 'ACTIVO');


insert into usuario values('0001','dCrispin',SHA('crispin'),1);
insert into usuario values('0002','eHuaman',SHA('huaman'),1);
insert into usuario values('0003','mMartinez',SHA('martinez'),1);
insert into usuario values('0004','jAlamo',SHA('alamo'),0);
insert into usuario values('0005','cRamirez',SHA('ramirez'),0);


INSERT INTO Permiso VALUES( '0001', 1, 'ACTIVO');
INSERT INTO Permiso VALUES( '0001', 2, 'ACTIVO');
INSERT INTO Permiso VALUES( '0001', 3, 'ACTIVO');
INSERT INTO Permiso VALUES( '0001', 4, 'ACTIVO');
INSERT INTO Permiso VALUES( '0001', 5, 'ACTIVO');
INSERT INTO Permiso VALUES( '0001', 6, 'ACTIVO');


INSERT INTO Permiso VALUES( '0002', 1, 'ACTIVO');
INSERT INTO Permiso VALUES( '0002', 2, 'ACTIVO');
INSERT INTO Permiso VALUES( '0002', 3, 'ACTIVO');
INSERT INTO Permiso VALUES( '0002', 4, 'ACTIVO');
INSERT INTO Permiso VALUES( '0002', 5, 'CANCELADO');
INSERT INTO Permiso VALUES( '0002', 6, 'CANCELADO');


INSERT INTO Permiso VALUES( '0003', 1, 'ACTIVO');
INSERT INTO Permiso VALUES( '0003', 2, 'CANCELADO');
INSERT INTO Permiso VALUES( '0003', 3, 'ACTIVO');
INSERT INTO Permiso VALUES( '0003', 4, 'ACTIVO');
INSERT INTO Permiso VALUES( '0003', 5, 'ACTIVO');
INSERT INTO Permiso VALUES( '0003', 6, 'CANCELADO');


insert into equipo values('0001','0001','0001','computadora','DELL','DPT-34','23423423','W7','labo_rrhh01','192.186.1.2','2015-10-09','2015-10-09','avtivo','Gerente de RRHH','1230000001');
insert into equipo values('0002','0001','0001','impresora','EPSON','DPT-34','23423423','W8',' - ','192.186.1.3','2015-10-09','2015-10-09','avtivo','Gerente de RRHH','1230000002');
insert into equipo values('0003','0001','0001','rauter','TPLINK','DPT-34','23423423','W8',' - ','192.186.1.5','2015-10-09','2015-10-09','avtivo','Gerente de RRHH','1230000003');
insert into equipo values('0004','0001','0001','computadora','ACER','DPT-34','23423423','W7','labo_rrhh02','192.186.1.6','2015-10-09','2015-10-09','inactivo','Gerente de RRHH','1230000004');
insert into equipo values('0005','0001','0001','computadora','COMPAQ','DPT-34','23423423','W7','labo_rrhh03','192.186.1.7','2015-10-09','2015-10-09','avtivo','Gerente de RRHH','1230000005');

insert into equipo values('0006','0002','0001','computadora','DELL','DPT-34','23423423','W7','labo_admi01','192.186.1.2','2015-10-09','2015-10-09','avtivo','Gerente de RRHH','1230000006');
insert into equipo values('0007','0002','0001','impresora','EPSON','DPT-34','23423423','W8',' - ','192.186.1.4','2015-10-09','2015-10-09','avtivo','Gerente de RRHH','1230000007');
insert into equipo values('0008','0002','0001','rauter','TPLINK','DPT-34','23423423','W10','-','192.186.1.5','2015-10-09','2015-10-09','inactivo','Gerente de RRHH','1230000008');
insert into equipo values('0009','0002','0001','computadora','ACER','DPT-34','23423423','W7','labo_admi02','192.186.1.6','2015-10-09','2015-10-09','avtivo','Gerente de RRHH','1230000009');
insert into equipo values('0010','0002','0001','computadora','COMPAQ','DPT-34','23423423','W7','labo_admi03','192.186.1.7','2015-10-09','2015-10-09','avtivo','Gerente de RRHH','1230000010');

insert into equipo values('0011','0003','0001','computadora','DELL','DPT-34','23423423','W7','labo_logis01','192.186.1.2','2015-10-09','2015-10-09','avtivo','Gerente de RRHH','1230000011');
insert into equipo values('0012','0003','0001','impresora','EPSON','DPT-34','23423423','W8','-','192.186.1.7','2015-10-09','2015-10-09','avtivo','Gerente de RRHH','1230000012');
insert into equipo values('0013','0003','0001','rauter','TPLINK','DPT-34','23423423','W10','-','192.186.1.8','2015-10-09','2015-10-09','inactivo','Gerente de RRHH','1230000013');
insert into equipo values('0014','0003','0001','computadora','ACER','DPT-34','23423423','W7','labo_logis02','192.186.1.9','2015-10-09','2015-10-09','avtivo','Gerente de RRHH','1230000014');
insert into equipo values('0015','0003','0001','computadora','COMPAQ','DPT-34','23423423','W7','labo_logis03','192.186.1.10','2015-10-09','2015-10-09','avtivo','Gerente de RRHH','1230000015');

insert into equipo values('0016','0004','0001','computadora','DELL','DPT-34','23423423','W7','labo_prosu01','192.186.1.2','2015-10-09','2015-10-09','avtivo','Gerente de RRHH','1230000016');
insert into equipo values('0017','0004','0001','impresora','EPSON','DPT-34','23423423','W8',' -','192.186.1.3','2015-10-09','2015-10-09','inactivo','Gerente de RRHH','1230000017');
insert into equipo values('0018','0004','0001','rauter','TPLINK','DPT-34','23423423','W10','-','192.186.1.5','2015-10-09','2015-10-09','avtivo','Gerente de RRHH','1230000018');
insert into equipo values('0019','0004','0001','computadora','ACER','DPT-34','23423423','W7','labo_prosu02','192.186.1.6','2015-10-09','2015-10-09','inactivo','Gerente de RRHH','1230000019');
insert into equipo values('0020','0004','0001','computadora','COMPAQ','DPT-34','23423423','W7','labo_prosu03','192.186.1.7','2015-10-09','2015-10-09','avtivo','Gerente de RRHH','1230000020');

insert into equipo values('0021','0005','0001','computadora','DELL','DPT-34','23423423','W7','labo_caja01','192.186.1.2','2015-10-09','2015-10-09','avtivo','Gerente de RRHH','1230000021');
insert into equipo values('0022','0005','0001','impresora','EPSON','DPT-34','23423423','W8','-','192.186.1.3','2015-10-09','2015-10-09','avtivo','Gerente de RRHH','1230000022');
insert into equipo values('0023','0005','0001','rauter','TPLINK','DPT-34','23423423','W10','-','192.186.1.4','2015-10-09','2015-10-09','inactivo','Gerente de RRHH','120000023');
insert into equipo values('0024','0005','0001','computadora','ACER','DPT-34','23423423','W7','labo_caja02','192.186.1.5','2015-10-09','2015-10-09','inactivo','Gerente de RRHH','1230000024');
insert into equipo values('0025','0005','0001','computadora','COMPAQ','DPT-35','23423423','W7','labo_caja03','192.186.1.6','2015-10-09','2015-10-09','avtivo','Gerente de RRHH','1230000025');


insert into hardware values('0001','si','si','si','1920 x 1080 ','24pulgadas','1TB','1G DDR3','si','si','si','si','si','si','dfgdfgdfg');
insert into hardware values('0002','si','si','si','1920 x 1080 ','24pulgadas','1TB','1G DDR3','si','si','si','si','si','si','dfgdfgdfg');
insert into hardware values('0003','si','si','si','1920 x 1080 ','24pulgadas','1TB','1G DDR3','si','si','si','si','si','si','dfgdfgdfg');
insert into hardware values('0004','si','si','si','1920 x 1080 ','24pulgadas','1TB','1G DDR3','si','si','si','si','si','si','dfgdfgdfg');
insert into hardware values('0005','si','si','si','1920 x 1080 ','24pulgadas','1TB','1G DDR3','si','si','si','si','si','si','dfgdfgdfg');                             

insert into hardware values('0006','si','si','si','1920 x 1080 ','24pulgadas','1TB','1G DDR3','si','si','si','si','si','si','dfgdfgdfg');
insert into hardware values('0007','si','si','si','1920 x 1080 ','24pulgadas','1TB','1G DDR3','si','si','si','si','si','si','dfgdfgdfg');
insert into hardware values('0008','si','si','si','1920 x 1080 ','24pulgadas','1TB','1G DDR3','si','si','si','si','si','si','dfgdfgdfg');
insert into hardware values('0009','si','si','si','1920 x 1080 ','24pulgadas','1TB','1G DDR3','si','si','si','si','si','si','dfgdfgdfg');
insert into hardware values('0010','si','si','si','1920 x 1080 ','24pulgadas','1TB','1G DDR3','si','si','si','si','si','si','dfgdfgdfg');                            

insert into hardware values('0011','si','si','si','1920 x 1080 ','24pulgadas','1TB','1G DDR3','si','si','si','si','si','si','dfgdfgdfg');
insert into hardware values('0012','si','si','si','1920 x 1080 ','24pulgadas','1TB','1G DDR3','si','si','si','si','si','si','dfgdfgdfg');
insert into hardware values('0013','si','si','si','1920 x 1080 ','24pulgadas','1TB','1G DDR3','si','si','si','si','si','si','dfgdfgdfg');
insert into hardware values('0014','si','si','si','1920 x 1080 ','24pulgadas','1TB','1G DDR3','si','si','si','si','si','si','dfgdfgdfg');
insert into hardware values('0015','si','si','si','1920 x 1080 ','24pulgadas','1TB','1G DDR3','si','si','si','si','si','si','dfgdfgdfg');                            

insert into hardware values('0016','si','si','si','1920 x 1080 ','24pulgadas','1TB','1G DDR3','si','si','si','si','si','si','dfgdfgdfg');
insert into hardware values('0017','si','si','si','1920 x 1080 ','24pulgadas','1TB','1G DDR3','si','si','si','si','si','si','dfgdfgdfg');
insert into hardware values('0018','si','si','si','1920 x 1080 ','24pulgadas','1TB','1G DDR3','si','si','si','si','si','si','dfgdfgdfg');
insert into hardware values('0019','si','si','si','1920 x 1080 ','24pulgadas','1TB','1G DDR3','si','si','si','si','si','si','dfgdfgdfg');
insert into hardware values('0020','si','si','si','1920 x 1080 ','24pulgadas','1TB','1G DDR3','si','si','si','si','si','si','dfgdfgdfg');                            

insert into hardware values('0021','si','si','si','1920 x 1080 ','24pulgadas','1TB','1G DDR3','si','si','si','si','si','si','dfgdfgdfg');
insert into hardware values('0022','si','si','si','1920 x 1080 ','24pulgadas','1TB','1G DDR3','si','si','si','si','si','si','dfgdfgdfg');
insert into hardware values('0023','si','si','si','1920 x 1080 ','24pulgadas','1TB','1G DDR3','si','si','si','si','si','si','dfgdfgdfg');
insert into hardware values('0024','si','si','si','1920 x 1080 ','24pulgadas','1TB','1G DDR3','si','si','si','si','si','si','dfgdfgdfg');
insert into hardware values('0025','si','si','si','1920 x 1080 ','24pulgadas','1TB','1G DDR3','si','si','si','si','si','si','dfgdfgdfg');


insert into diagnostico values('0001','0001','0001','fuente de poder malogrado','comprar otro','diagnostico y cambio de fuente','2015-10-09','');
insert into diagnostico values('0002','0001','0001','fuente de poder malogrado','comprar otro','diagnostico y cambio de fuente','2015-10-09','');
insert into diagnostico values('0003','0001','0002','fuente de poder malogrado','comprar otro','diagnostico y cambio de fuente','2015-10-09','');
insert into diagnostico values('0004','0001','0001','fuente de poder malogrado','comprar otro','diagnostico y cambio de fuente','2015-10-09','');
insert into diagnostico values('0005','0001','0001','fuente de poder malogrado','comprar otro','diagnostico y cambio de fuente','2015-10-09','');
insert into diagnostico values('0006','0002','0003','fuente de poder malogrado','comprar otro','diagnostico y cambio de fuente','2015-10-09','');
insert into diagnostico values('0007','0002','0001','fuente de poder malogrado','comprar otro','diagnostico y cambio de fuente','2015-10-09','');
insert into diagnostico values('0008','0002','0004','fuente de poder malogrado','comprar otro','diagnostico y cambio de fuente','2015-10-09','');
insert into diagnostico values('0009','0002','0001','fuente de poder malogrado','comprar otro','diagnostico y cambio de fuente','2015-10-09','');
insert into diagnostico values('0010','0002','0001','fuente de poder malogrado','comprar otro','diagnostico y cambio de fuente','2015-10-09','');
insert into diagnostico values('0011','0003','0001','fuente de poder malogrado','comprar otro','diagnostico y cambio de fuente','2015-10-09','');
insert into diagnostico values('0012','0003','0001','fuente de poder malogrado','comprar otro','diagnostico y cambio de fuente','2015-10-09','');
insert into diagnostico values('0013','0003','0001','fuente de poder malogrado','comprar otro','diagnostico y cambio de fuente','2015-10-09','');
insert into diagnostico values('0014','0003','0001','fuente de poder malogrado','comprar otro','diagnostico y cambio de fuente','2015-10-09','');
insert into diagnostico values('0015','0003','0001','fuente de poder malogrado','comprar otro','diagnostico y cambio de fuente','2015-10-09','');
insert into diagnostico values('0016','0004','0001','fuente de poder malogrado','comprar otro','diagnostico y cambio de fuente','2015-10-09','');
insert into diagnostico values('0017','0004','0001','fuente de poder malogrado','comprar otro','diagnostico y cambio de fuente','2015-10-09','');
insert into diagnostico values('0018','0004','0002','fuente de poder malogrado','comprar otro','diagnostico y cambio de fuente','2015-10-09','');
insert into diagnostico values('0019','0004','0001','fuente de poder malogrado','comprar otro','diagnostico y cambio de fuente','2015-10-09','');
insert into diagnostico values('0020','0004','0001','fuente de poder malogrado','comprar otro','diagnostico y cambio de fuente','2015-10-09','');
insert into diagnostico values('0021','0005','0003','fuente de poder malogrado','comprar otro','diagnostico y cambio de fuente','2015-10-09','');
insert into diagnostico values('0022','0005','0001','fuente de poder malogrado','comprar otro','diagnostico y cambio de fuente','2015-10-09','');
insert into diagnostico values('0023','0005','0002','fuente de poder malogrado','comprar otro','diagnostico y cambio de fuente','2015-10-09','');
insert into diagnostico values('0024','0005','0001','fuente de poder malogrado','comprar otro','diagnostico y cambio de fuente','2015-10-09','');
insert into diagnostico values('0025','0005','0003','fuente de poder malogrado','comprar otro','diagnostico y cambio de fuente','2015-10-09','');


USE MYSQL;
GRANT ALL PRIVILEGES ON *.* TO 'darwin'@'%' IDENTIFIED BY 'admin' WITH GRANT OPTION;
FLUSH PRIVILEGES;

GRANT ALL PRIVILEGES ON *.* TO 'darwin'@'localhost' IDENTIFIED BY 'admin' WITH GRANT OPTION;
FLUSH PRIVILEGES;

USE bdsiaec;


select 
e.id_equipo codigo,
l.nomLabo area,
e.inmovilizado codInmovil,
e.hostname hostname,
e.sisOpe so,
e.ip ip,
e.estado estado,
e.inmovilizado 
from equipo e inner join hardware h on e.id_equipo=h.id_equipo 
join laboratorio l on l.id_laboratorio=e.id_laboratorio 
where l.id_laboratorio like"0001";
 
select 
e.id_equipo cod,
l.nomLabo area,
e.inmovilizado codInmovil,
e.hostname hostname,
e.sisOpe so,
e.ip ip,
e.estado estado,
e.inmovilizado 
from equipo e 
inner join laboratorio l 
on e.id_laboratorio=l.id_laboratorio
 where l.id_laboratorio='0002';
 
 
SELECT    
E.id_equipo codigo,
L.nomLabo  area,
L.jefe_labo  jefe,
E.marca  marca,
E.sisOpe sisOp,
H.teclado  teclado,
H.mouse  mouse,
H.monitor  monitor,
H.discoDuro  discoDuro 
FROM equipo E  
INNER JOIN hardware H 
ON E.id_equipo = H.id_equipo 
INNER JOIN laboratorio L 
ON E.id_laboratorio = L.id_laboratorio 
WHERE E.id_equipo = '0001';




create table diagnostico(
id_equipo       CHAR(4) NOT NULL,
id_laboratorio  CHAR(4) NOT NULL,
id_empleado     CHAR(4) NOT NULL,
descripProble   varchar(150) ,
sugerencia      varchar(150) ,
activiRealizada varchar(150) ,
fecha           date ,
hora            time  default null,
constraint fk_diagEqui foreign key(id_equipo) references equipo(id_equipo),
constraint fk_diagLabo foreign key(id_laboratorio) references laboratorio(id_laboratorio),
constraint fk_diagEmple foreign key(id_empleado) references usuario(id_empleado)
);

insert into diagnostico values('0001','0001','0001','fuente de poder malogrado','comprar otro','diagnostico y cambio de fuente','2015-10-09','');
 
SELECT   
E.id_equipo  id_equipo, 
D.id_laboratorio   id_laboratorio, 
D.id_empleado      id_empleado , 
D.descripProble    descripProble,  
D.sugerencia       sugerencia,      
D.activiRealizada  activiRealizada, 
D.fecha            fecha,           
D.hora             hora           
FROM equipo E   
INNER JOIN diagnostico D  
ON E.id_equipo = D.id_equipo 
where E.id_equipo like '%0001%' 
or E.inmovilizado like '%1230000001%'; 

SELECT
id_equipo  id_equipo, 
id_laboratorio   id_laboratorio, 
id_empleado      id_empleado , 
descripProble    descripProble,  
sugerencia       sugerencia,      
activiRealizada  activiRealizada, 
fecha            fecha,           
hora             hora           
FROM diagnostico  
where E.id_equipo like '%0001%' 
or E.inmovilizado like '%1230000001%'; 

 
 
 
 
 
 
 
 