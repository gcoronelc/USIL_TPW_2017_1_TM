//CONSULTA DE DIAGNOSTICO


SELECT   
E.id_equipo  id_equipo, 
D.id_laboratorio   id_laboratorio, 
D.id_empleado      id_empleado , 
D.descripProble    descripProble,  
D.sugerencia       sugerencia,      
D.activiRealizada  activiRealizada, 
D.fecha            fecha,           
D.hora             hora           
FROM equipo E   
INNER JOIN diagnostico D  
ON E.id_equipo = D.id_equipo 
where E.id_equipo like '%_0001_%' 
or E.inmovilizado like '%_1230000009_%'; 


INSERT INTO 
	id_equipo	     	
	id_laboratorio
	id_empleado
	tipoEquipo
	marca
	modelo
	serie
	sisOpe
	hostname
	ip
	fecha_reg
	fecha_baj
	estado
	responsable
	inmovilizado
	
	
	
	
	
	