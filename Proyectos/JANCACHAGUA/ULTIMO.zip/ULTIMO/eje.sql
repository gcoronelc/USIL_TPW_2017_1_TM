

insert into equipo (select 
id_equipo        id_equipo,
id_laboratorio   id_laboratorio,
id_empleado      id_empleado,
tipoEquipo       tipoEquipo,
marca            marca  ,
modelo           modelo      ,
serie            serie       ,
sisOpe           sisOpe      ,
hostname         hostname    ,
ip               ip          ,
fecha_reg        fecha_reg ,  
fecha_baj        fecha_baj , 
estado           estado      ,
responsable      responsable ,
inmovilizado     inmovilizadonot
from equipo
);



create table equipo(
id_equipo        CHAR(4) NOT NULL,
id_laboratorio   CHAR(4) NOT NULL,
id_empleado      CHAR(4) NOT NULL,
tipoEquipo       varchar(50) not null,
marca            varchar(50),
modelo           varchar(50),
serie            varchar(50),
sisOpe           varchar(50),
hostname         varchar(50),
ip               varchar(50),
fecha_reg        date ,
fecha_baj        date ,
estado           varchar(50),
responsable      varchar(50),
inmovilizado     varchar(50)not null,
CONSTRAINT PK_Equipo PRIMARY KEY (id_equipo),
constraint fk_laboEqui foreign key(id_laboratorio) references laboratorio(id_laboratorio),
constraint fk_EmpleEqui foreign key(id_empleado) references usuario(id_empleado)
);







